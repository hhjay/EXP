-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2015-01-07 15:18:10
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sqlexp`
--

-- --------------------------------------------------------

--
-- 表的结构 `beiwang`
--

CREATE TABLE IF NOT EXISTS `beiwang` (
  `b_id` int(8) NOT NULL AUTO_INCREMENT,
  `b_con` text NOT NULL,
  `b_time` int(16) NOT NULL,
  `u_id` int(8) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `beiwang`
--

INSERT INTO `beiwang` (`b_id`, `b_con`, `b_time`, `u_id`) VALUES
(3, 'asdasdsadadasdasd\r\n', 1419988190, 13),
(4, '今天要去拔牙，记得取钱。', 1419908089, 11),
(5, '今天要去拔牙，记得取钱。', 1419908406, 11),
(6, '今天要去拔牙，记得取钱啊啊啊。', 1419912229, 11);

-- --------------------------------------------------------

--
-- 表的结构 `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `c_id` int(8) NOT NULL AUTO_INCREMENT,
  `m_id` int(8) NOT NULL,
  `c_con` text NOT NULL,
  `c_time` int(16) NOT NULL,
  `u_id` int(8) NOT NULL COMMENT '评论的用户',
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- 转存表中的数据 `comment`
--

INSERT INTO `comment` (`c_id`, `m_id`, `c_con`, `c_time`, `u_id`) VALUES
(19, 30, '冯总好样的', 1419777446, 13),
(20, 33, 'nihao', 1419988214, 13);

-- --------------------------------------------------------

--
-- 表的结构 `memo`
--

CREATE TABLE IF NOT EXISTS `memo` (
  `m_id` int(8) NOT NULL AUTO_INCREMENT,
  `m_loc` varchar(16) NOT NULL,
  `m_main` text NOT NULL,
  `m_per` varchar(32) NOT NULL COMMENT '参与人',
  `m_time` int(16) NOT NULL,
  `u_id` int(8) NOT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- 转存表中的数据 `memo`
--

INSERT INTO `memo` (`m_id`, `m_loc`, `m_main`, `m_per`, `m_time`, `u_id`) VALUES
(30, '宿舍', '富强民主 文明和谐 爱国敬业 诚信友善 ', '冯超', 1419777005, 12),
(32, '南书院', '这么一个简单的事情，别说我不等你。', 'fc', 1419901215, 13),
(33, '大活', '这么一个简单的事情，自己搞定。', '自己', 1419912289, 11);

-- --------------------------------------------------------

--
-- 表的结构 `tongxun`
--

CREATE TABLE IF NOT EXISTS `tongxun` (
  `t_id` int(8) NOT NULL AUTO_INCREMENT,
  `u_id` int(8) NOT NULL,
  `t_phone` varchar(16) NOT NULL,
  `t_loc` varchar(64) NOT NULL,
  `t_city` varchar(8) NOT NULL,
  `t_beizhu` varchar(64) NOT NULL,
  `t_name` varchar(8) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `tongxun`
--

INSERT INTO `tongxun` (`t_id`, `u_id`, `t_phone`, `t_loc`, `t_city`, `t_beizhu`, `t_name`) VALUES
(1, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(2, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(3, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(4, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(5, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(6, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(7, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(8, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(9, 12, '13260548599', 'china', 'wuhan', 'beizhu', ''),
(10, 12, '13297903920', '中南民族大学', '武汉', '武汉号', 'hhj'),
(11, 12, '13297903920', '中南民族大学', '武汉', '武汉号', 'hhj'),
(12, 12, '13297903920', '中南民族大学', '武汉', '武汉号', 'hhj');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `u_id` int(8) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(16) NOT NULL,
  `u_pwd` varchar(64) NOT NULL,
  `u_time` int(16) NOT NULL,
  `u_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`u_id`, `u_name`, `u_pwd`, `u_time`, `u_ip`) VALUES
(11, 'gz', '8687afb9f7b0846291f094742f56ac68abd2dd1c', 1418913162, '127.0.0.1'),
(12, 'fc', '379da9e51ae8a3d8ca0a1b0c9fa1884f78404e70', 1418913200, '127.0.0.1'),
(13, 'hhj', '3b6653d05e988e5624f02c3e3c621dd1ad90464f', 1419739035, '127.0.0.1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
