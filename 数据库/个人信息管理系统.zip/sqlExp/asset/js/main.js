$(document).ready(function() {
	$(".main li").click(function(){
		$(this).siblings().css({"color": "#000","background-color": "#dff"});
		$(this).css({"color": "red","background-color": "#ddd"});
		$("#"+$(this).attr("class")).siblings().removeClass("show");
		$("#"+$(this).attr("class")).addClass("show");
	});
	$(".RconLi b").click(function(){
		$(this).css("color","red");
		$(this).parent().siblings("form").css("display","block")
	});
	// $(".RconLi p").hover(
	// 	function(){
	// 		$(this).siblings().children(".deleteDay").css("display","block");
	// 	},function() {
	// 		$(this).siblings().children(".deleteDay").css("display","none");
	// 	}
	// );
	$(".updata_bw").click(function() {//备忘录修改
		var con = $(this).parent().siblings("p").html();
		var b_id = $(this).siblings("i").html();
		$(".upd").css("display","block");
		$("#b_id").val(b_id);
		$(".bw_upd_con").val(con);
	});
	$("#cancel").click(function() {
		$(".upd").css("display","none");
	})
})