<?php 
date_default_timezone_set("Asia/Shanghai");
/**
* login and so on
*/
class M_login extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	public function check_login($data) {
		$name = $data["u_name"];
		$sql = "SELECT * FROM user WHERE u_name = '$name' LIMIT 1";
		$res = $this ->db ->query($sql)->row_array();
		if ($res) { //有这个用户
			if (SHA1($data["u_pwd"].$res["u_time"])==$res["u_pwd"]) {
				return $res;
			}else {
				return FALSE;
			}
		}else {
			return FALSE;
		}
	}
	public function check_new($data) {
		$sql = "SELECT u_name FROM user WHERE u_name = '$data' LIMIT 1";
		$res = $this ->db ->query($sql) ->row_array();
		if ($res) {
			return $res;
		}else{
			return FALSE;
		}
	}
	public function add_user($data) {
		$this ->db ->insert("user",$data);
	}
	public function add_per($data) {
		$this ->db ->insert('tongxun',$data);
	}
	public function add_day($data) {
		$this ->db ->insert("memo",$data);
	}
	public function add_comm($data) {
		$this ->db ->insert("comment",$data);
	}
	public function add_bw($data) {
		$this ->db ->insert("beiwang",$data);
	}
	public function selsct_tx() {// 返回通讯录
		$res = $this ->db ->query("SELECT * FROM tongxun ORDER BY t_id DESC");
		return $res->result();
	}
	public function select_bw($data) {
		$res = $this ->db ->query("SELECT * FROM beiwang WHERE u_id = '$data' ORDER BY b_time DESC");
		return $res->result();
	}
	public function selsct_day() {// 返回日记
		$res = array();
		$rj_data = $this ->db ->query("SELECT * FROM memo ORDER BY m_time DESC");
		$rj_data = $rj_data->result();
		foreach ($rj_data as $row) {
			$u_id = $row ->u_id;
			$sql = "SELECT u_name FROM user WHERE u_id = '$u_id' LIMIT 1";
			$query = $this ->db ->query($sql);
			$u_name_q = $query ->row_array();
			$u_name = $u_name_q["u_name"]; 
			$row->u_name = $u_name;
			array_push($res, $row);
		}
		return $res;
	}
	public function select_comm() {//返回评论
		$return = array();
		$res = $this ->db ->query("SELECT * FROM comment ORDER BY c_id DESC");
		$res = $res ->result();
		foreach ($res as $row) {
			$u_id = $row ->u_id;
			$query = $this ->db ->query("SELECT u_name FROM user WHERE u_id = '$u_id' LIMIT 1");
			$u_name_e = $query ->row_array();
			$c_u_name = $u_name_e["u_name"];
			$row->c_u_name = $c_u_name;
			array_push($return, $row);
		}
		return $return;
	}
	public function delete_day($m_id) {
		$sql = "DELETE FROM memo WHERE m_id = '$m_id'";
		mysql_query($sql);
	}
	public function upd_bw($data) {
		$sql = "UPDATE beiwang SET b_con='$data[b_con]',b_time='$data[b_time]' WHERE b_id='$data[b_id]'";
		mysql_query($sql);
	}
}
?>