<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>add user</title>
</head>
<body>
<form action="<?php echo base_url() ?>index.php/index/add_user" method="post">
	<label for="user">username:</label>
	<input type="text" name="user" id="user" /><br/><br/>
	<label for="pwd">password:</label>
	<input type="password" name="pwd" id="pwd" /><br/><br/>
	<label for="d_pwd">d_passwo:</label>
	<input type="password" name="d_pwd" id="d_pwd" /><br/><br/>
	<input type="submit" name="sub" />
	<a href="<?php echo base_url() ?>index.php/index/check_login">登陆</a>
</form>
</body>
</html>