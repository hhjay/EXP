<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>login</title>
</head>
<body>
<form action="<?php echo base_url() ?>index.php/index/check_login" method="post">
	<label for="user">username:</label>
	<input type="text" name="user" id="user" value="" /><br/><br/>
	<label for="pwd">password:</label>
	<input type="password" name="pwd" id="pwd" /><br/><br/>
	<input type="submit" name="sub" />
	<a href="<?php echo base_url(); ?>index.php/index/add_user">新增</a>
</form>
</body>
</html>