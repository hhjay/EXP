<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>index</title>
	<script type="text/javascript" src="<?php echo base_url() ?>asset/js/jquery.1.11.0.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>asset/css/main.css">
</head>
<body>
<?php 
	echo "在线用户：".$session['u_name']."&nbsp;";
?>
<a href="<?php echo base_url() ?>index.php/index/logout">注销</a>
<div class="main">
	<ul>
		<li class="person">通讯录</li>
		<li class="beiwang">备忘录</li>
		<li class="riji">日记</li>
		<!-- <li class="caichan">我的财产</li> -->
	</ul>