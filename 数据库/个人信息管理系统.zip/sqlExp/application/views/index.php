	<div id="person" class="con show">
		<div class="conUl">
		<?php foreach ($tx_data as $row) { ?>
			<div class="conLi">
				<?php echo "phone:".$row->t_phone; ?>
				<p><?php echo "who:".$row->t_name." ".$row->t_beizhu; ?></p>
				<span><?php echo $row->t_city." ".$row->t_loc; ?></span>
			</div>
		<?php } ?>
		</div>
		<form action="<?php echo base_url() ?>index.php/index/add_tx" method="post" class="lForm">
			<label for="user">user:</label>
			<input type="text" name="user" id="user" /><br/><br/>
			<label for="phone">phone:</label>
			<input type="text" name="phone" id="phone" /><br/><br/>
			<label for="loc">地址:</label>
			<input type="text" name="loc" id="loc" /><br/><br/>
			<label for="city">city:</label>
			<input type="text" name="city" id="city" /><br/><br/>
			<label for="beizhu">备注:</label>
			<input type="text" name="beizhu" id="beizhu" /><br/><br/>
			<input type="submit" name="sub" value="增加" />
		</form>
	</div>
	<div id="beiwang" class="con">
		<form action="<?php echo base_url() ?>index.php/index/add_bw" method="post" class="lForm">
			<input type="hidden" name="b_u_id" value="<?php echo $session['u_id'] ?>"  />
			<label for="con">备忘内容:</label>
			<textarea cols="22" rows="5" name="con"></textarea></br></br>
			<input type="submit" name="sub" value="增加" />
		</form>
		<div class="conUl">
			<?php foreach ($beiwang as $b_row) { ?>
			<div class="RconLi">
				<p><?php echo $b_row->b_con ?></p>
				<span>
					<button class="deleteDay updata_bw">修改</button>
					<i><?php echo $b_row->b_id ?></i>
					<?php echo date("Y/m/d H:s",$b_row->b_time); ?>
				</span>
			</div>
			<?php } ?>
		</div>
		<div class="upd">
			<form action="<?php echo base_url() ?>index.php/index/upd_bw" method="post" class="uForm">
				<input type="hidden" name="b_id" id="b_id"  />
				<label for="con">备忘内容:</label>
				<textarea cols="22" rows="5" name="con" class="bw_upd_con"></textarea></br></br>
				<input type="submit" name="sub" value="修改" />
				<input type="button" id="cancel" value="取消" />
			</form>
		</div>
	</div>
	<div id="riji" class="con">
		<div class="conUl">
		<?php foreach ($comment as $row) { ?>
			<div class="RconLi">
				<p><?php echo $row->u_name."在-".$row->m_loc.'发表:'.$row->m_main."  参与人".$row->m_per; ?></p>
				<span>
					<?php     //判断是否可以被删除 
						if ($row->u_name==$session['u_name']) {
							echo "<a class='deleteDay' href='".base_url();
							echo "index.php/index/delete_day/".$row ->m_id."'>删除</a>";
						}
					?>
					<b>评论</b>&nbsp;&nbsp;&nbsp;<?php echo date("Y/m/d H:s",$row->m_time); ?>
				</span>
				<?php
				foreach ($pinglun as $key) {
					if ($key->m_id==$row->m_id) {
						echo $key->c_u_name."评论:".$key->c_con."  time:".date("Y/m/d H:s",$key->c_time)."<br/>";
					}
				}
				?>
				<form action="<?php echo base_url() ?>index.php/index/add_comm" method="post" class="comm_form">
					<input type="hidden" name="m_id" value="<?php echo $row->m_id; ?>" />
					<input type="text" name="con" />
				</form>
			</div>
		<?php } ?>
		</div>
		<form action="<?php echo base_url() ?>index.php/index/add_day" method="post" class="lForm">
			<label for="loc">地址:</label>
			<input type="text" name="loc" id="loc" /><br/><br/>
			<label for="per">参与人:</label>
			<input type="text" name="per" id="per" /><br/><br/>
			<label for="con">内容:</label>
			<textarea cols="22" rows="5" name="con"></textarea></br></br>
			<input type="submit" name="sub" value="增加" />
		</form>
	</div>
	<!-- <div id="caichan" class="con">财产</div> -->
</div>
<script type="text/javascript" src="<?php echo base_url() ?>asset/js/main.js"></script>
</body>
</html>