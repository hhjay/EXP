<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Index extends CI_Controller {
	public function __construct() {
		date_default_timezone_set("Asia/Shanghai");
		parent::__construct();
		$this ->load ->helper("url");
		$this ->load ->library("session");
		$this ->load ->model("m_login");
	}
	public function index() {
		$config["base_url"] = base_url()."index.php/index";
		$session_data = $this ->session ->userdata("u_id");
		if (empty($session_data)) {
			$this ->load ->view("add_user");
		}else{
			$session_data = $this ->session ->all_userdata();
			$data['session'] = $session_data;
			$data['tx_data'] = $this ->m_login ->selsct_tx();
			$data["comment"] = $this ->m_login ->selsct_day();//日记
			$data["pinglun"] = $this ->m_login ->select_comm();//评论
			$data["beiwang"] = $this ->m_login ->select_bw($session_data["u_id"]);//备忘录
			$this->load->view('header',$data);
			$this->load->view('index',$data);
		}
	}
	public function check_login() {//登陆
		$this ->load ->library("form_validation");
		$this ->form_validation ->set_rules("user","User","required");
		$this ->form_validation ->set_rules("pwd","Pwd","required");
		$data = array(
			"u_name" =>$this ->input ->post("user"),
			"u_pwd"  =>$this ->input ->post("pwd"),
			"u_ip" 	 =>$this ->input ->ip_address,
			"u_time" =>time()
		);
		if ($this ->form_validation ->run() == FALSE) {
			echo "form error,<a href='index/add_user'>add</a>";
			$this ->load ->view("login",$data);
		}else{
			$res = $this ->m_login ->check_login($data);
			if ($res) {
				$this ->session ->set_userdata($res);
				$session_data = $this ->session ->all_userdata();
				// $session_data = $this ->session ->userdata("u_id"); #just u_id
				$data["session"] = $session_data;
				$data['tx_data'] = $this ->m_login ->selsct_tx();
				$data["comment"] = $this ->m_login ->selsct_day();//日记
				$data["pinglun"] = $this ->m_login ->select_comm();//评论
				$data["beiwang"] = $this ->m_login ->select_bw($session_data["u_id"]);//备忘录
				$this ->load ->view("header",$data);
				$this ->load ->view("index",$data);
			}else {
				echo "user or pwd is error";
				redirect('/');
			}
		}
	}
	public function logout() {//注销
		$this ->session ->sess_destroy();
		$this ->load ->view("login");
	}
	public function add_user() {//注册
		$this ->load ->library("form_validation");
		$this ->form_validation ->set_rules("user","User","required");
		$this ->form_validation ->set_rules("pwd","Pwd","required");
		$this ->form_validation ->set_rules("d_pwd","Pwd Confirmation","required");
		$pwd = $this ->input ->post("pwd");
		$pwd = SHA1($pwd.time());
		$data = array(
			"u_name" =>$this ->input ->post("user"),
			"u_ip" 	 =>$this ->input ->ip_address(),
			"u_pwd"  =>$pwd,
			"u_time" =>time()
		);
		if ($this->form_validation->run() == FALSE) {
			echo "new user form error";
			$this ->load ->view("add_user");
		}else {
			$res = $this ->m_login ->check_new($data["u_name"]);
			if ($res) {
				echo "this user name is have";
				$this ->load ->view("add_user");
			}else{
				$this ->m_login ->add_user($data);
				$data["session"] = $this ->session ->all_userdata();
				echo "new user success";
				$this ->load ->view("login",$data);
			}
		}
	}
	public function add_tx() {//通讯录
		$this ->load ->library("form_validation");
		$this ->form_validation ->set_rules("user","User","required");
		$this ->form_validation ->set_rules("phone","Phone","required");
		$this ->form_validation ->set_rules("loc","Loc","required");
		$this ->form_validation ->set_rules("city","City","required");
		$this ->form_validation ->set_rules("beizhu","Beizhu","required");
		$session_data = $this ->session ->all_userdata();
		$add_data = array(
			"u_id" =>$session_data["u_id"],
			"t_name" =>$this ->input ->post("user"),
			"t_phone" =>$this ->input ->post("phone"),
			"t_loc" =>$this ->input ->post("loc"),
			"t_city" =>$this ->input ->post("city"),
			"t_beizhu" =>$this ->input ->post("beizhu")
		);
		if ($this->form_validation->run()==FALSE) {
			redirect("/");
		}else{
			$this ->m_login ->add_per($add_data);
			$data['tx_data'] = $this ->m_login ->selsct_tx();
			$data["comment"] = $this ->m_login ->selsct_day();//日记
			$data["pinglun"] = $this ->m_login ->select_comm();//评论
			$data["beiwang"] = $this ->m_login ->select_bw($session_data["u_id"]);//备忘录
			$data["session"] = $session_data;
			$this->load->view('header',$data);
			$this ->load ->view("index",$data);
		}
	}
	public function add_day() {//日记
		$this ->load ->library("form_validation");
		$this ->form_validation ->set_rules("loc","Loc","required");
		$this ->form_validation ->set_rules("per","Per","required");
		$this ->form_validation ->set_rules("con","Con","required");
		$session_data = $this ->session ->all_userdata();
		$add_data = array(
			"u_id" =>$session_data["u_id"],//发布人
			"m_loc" =>$this ->input ->post("loc"),
			"m_main" =>$this ->input ->post("con"),//日记内容
			"m_per" =>$this ->input ->post("per"),//参与人
			"m_time" =>time()
		);
		if ($this->form_validation->run()==FALSE) {
			redirect("/");
		}else{
			$this ->m_login ->add_day($add_data);
			$data['tx_data'] = $this ->m_login ->selsct_tx();//通讯录
			$data["comment"] = $this ->m_login ->selsct_day();//日记
			$data["pinglun"] = $this ->m_login ->select_comm();//评论
			$data["beiwang"] = $this ->m_login ->select_bw($session_data["u_id"]);//备忘录
			$data["session"] = $session_data;
			$this->load->view('header',$data);
			$this ->load ->view("index",$data);
		}
	}
	public function add_comm() {//评论
		$this ->load ->library("form_validation");
		$this ->form_validation ->set_rules("con","Con","required");
		$session_data = $this ->session ->all_userdata();
		$add_data = array(
			"m_id" 	=>$this ->input ->post("m_id"),
			"c_con" =>$this ->input ->post("con"),
			"u_id"	=>$session_data["u_id"],
			"c_time" =>time()
		);
		if ($this->form_validation->run()==FALSE) {
			redirect("/");
		}else{
			$this ->m_login ->add_comm($add_data);
			$data['tx_data'] = $this ->m_login ->selsct_tx();//通讯录
			$data["comment"] = $this ->m_login ->selsct_day();//日记
			$data["pinglun"] = $this ->m_login ->select_comm();//评论
			$data["beiwang"] = $this ->m_login ->select_bw($session_data["u_id"]);//备忘录
			$data["session"] = $session_data;
			$this->load->view('header',$data);
			$this ->load ->view("index",$data);
		}
	}
	public function delete_day($m_id) {
		$this ->m_login ->delete_day($m_id);
		$session_data = $this ->session ->all_userdata();
		$data['tx_data'] = $this ->m_login ->selsct_tx();//通讯录
		$data["comment"] = $this ->m_login ->selsct_day();//日记
		$data["pinglun"] = $this ->m_login ->select_comm();//评论
		$data["beiwang"] = $this ->m_login ->select_bw($session_data["u_id"]);//备忘录
		$data["session"] = $session_data;
		$this->load->view('header',$data);
		$this ->load ->view("index",$data);
	}
	public function add_bw() {// 添加备忘录
		$this ->load ->library("form_validation");
		$this ->form_validation ->set_rules("con","Con","required");
		$add_data = array(
			"b_con" =>$this ->input ->post("con"),
			"b_time" =>time(),
			"u_id"	=>$this ->input ->post("b_u_id")
		);
		if ($this->form_validation->run()==FALSE) {
			redirect("/");
		}else{
			$this ->m_login ->add_bw($add_data);
			$session_data = $this ->session ->all_userdata();
			$data['tx_data'] = $this ->m_login ->selsct_tx();//通讯录
			$data["comment"] = $this ->m_login ->selsct_day();//日记
			$data["pinglun"] = $this ->m_login ->select_comm();//评论
			$data["beiwang"] = $this ->m_login ->select_bw($session_data["u_id"]);//备忘录
			$data["session"] = $session_data;//登陆信息
			$this->load->view('header',$data);
			$this ->load ->view("index",$data);
		}
	}
	public function upd_bw() {
		$this ->load ->library("form_validation");
		$this ->form_validation ->set_rules("con","Con","required");
		$upd_data = array(
			"b_con" =>$this ->input ->post("con"),
			"b_time" =>time(),
			"b_id"	=>$this ->input ->post("b_id")
		);
		if ($this->form_validation->run()==FALSE) {
			redirect("/");
		}else{
			$this ->m_login ->upd_bw($upd_data);
			$session_data = $this ->session ->all_userdata();
			$data['tx_data'] = $this ->m_login ->selsct_tx();//通讯录
			$data["comment"] = $this ->m_login ->selsct_day();//日记
			$data["pinglun"] = $this ->m_login ->select_comm();//评论
			$data["beiwang"] = $this ->m_login ->select_bw($session_data["u_id"]);//备忘录
			$data["session"] = $session_data;//登陆信息
			$this->load->view('header',$data);
			$this ->load ->view("index",$data);
		}
	}
}